var websock;

function start() {
    websock = new WebSocket('ws://' + window.location.hostname + '/ws');
    websock.onopen = function(evt) {
        console.log('ESP WebSock Open');
        websock.send('{"command":"getconf"}');
    };
    websock.onclose = function(evt) {
        console.log('ESP WebSock Close');
    };
    websock.onerror = function(evt) {
        console.log(evt);
    };
    websock.onmessage = function(evt) {
        console.log(evt.data);
        obj = JSON.parse(evt.data);
        if (obj.command == "ssidlist") {
            listSSID(obj);
        } else if (obj.command == "configfile") {
            listCONF(obj);
        } 
    };
}

function listCONF(obj) {
    console.log(obj);
    document.getElementById('inputtohide').value = obj.ssid;
    document.getElementById('wifipass').value = obj.pswd;
}

function listSSID(obj) {
    var select = document.getElementById('ssid');
    for (var i = 0; i < obj.ssid.length; i++) {
        var x = obj.ssid[i];
        var opt = document.createElement('option');
        opt.value = x;
        opt.innerHTML = x;
        select.appendChild(opt);
    }
    document.getElementById('scanb').innerHTML = 'Re-Scan';
}

function scanWifi() {
    websock.send('{"command":"scan"}');
    document.getElementById('scanb').innerHTML = '...';
    document.getElementById('inputtohide').style.display = 'none';
    var node = document.getElementById('ssid');
    node.style.display = 'inline';
    while (node.hasChildNodes()) {
        node.removeChild(node.lastChild);
    }
}

function saveConf() {
    var ssid;
    if (document.getElementById('inputtohide').style.display == 'none') {
        var b = document.getElementById('ssid');
        ssid = b.options[b.selectedIndex].value;
    } else {
        ssid = document.getElementById('inputtohide').value;
    }
    var datatosend = {};
    datatosend.command = "configfile";
    datatosend.ssid = ssid;
    datatosend.pswd = document.getElementById('wifipass').value;
    console.log(JSON.stringify(datatosend));
    websock.send(JSON.stringify(datatosend));
}